#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""apply.py — детерминированный single-apply Редколлегии (Шаг 3 конвейера).

Detect-этапы (Аграновский, Слопотрон) текст не переписывают, а отдают находки с дословной
цитатой `quote` и заменой `edit`. Если вносить их руками оркестратора-LLM, это самое
хрупкое место конвейера: модель может «чуть подправить» соседнее слово, пропустить перекрытие
или дописать абзац. Здесь то же самое делает код, поэтому соответствие текста находкам
выполняется по построению (идея span-patch из gasyoun/RuWritingStyles, Apache-2.0; код свой).

Что делает (порядок важен):
  1. Раскладывает находки по `action`: `applied` — уже внесено переписчиком (транзит);
     `suggest` — автору; `flag` — замены нет, автору (blocker зон facts/meaning — активный);
     `apply`/`redirect` с `edit` — применимые; неизвестный `action` — автору, не вносится.
     Синонимы replace/fix/edit/correct (регистр не важен) с непустым `edit` приводятся
     к `apply` с пометкой `note` в отчёте.
  2. Дедуп: одна `quote` + один `edit` от двух этапов → одна правка; одна `quote` + разные
     `edit` → конфликт, обе автору.
  3. Якорение: `quote` ищется в тексте дословно (с допуском на разницу пробелов). Не найдена
     или встречается больше одного раза → автору (скрипт не угадывает, какое вхождение).
  3а. Защищённые цитаты (--protected): правка, чей span перекрывается с защищённой строкой,
     не вносится — автору с причиной «защищённая цитата».
  4. Перекрытие span — геометрически, по позициям в исходном тексте: пересекающиеся правки
     отдаются автору обе.
  5. Бюджет роста: суммарный прирост знаков от применённых правок ≤ ratio × длина текста
     (по умолчанию 0.2). Сверх бюджета вытесняются правки с наибольшим приростом, начиная
     с самой «раздувающей». Исправление blocker зон facts/meaning не вытесняется никогда —
     это исправление ошибки, а не стиль. Кластер Слопотрона вытесняется наравне с fix.
  6. Применение с конца текста к началу (позиции не сдвигаются).
  7. Раздел автора: находки, чьи цитаты вложены одна в другую или перекрываются в тексте
     ≥ 60% (от более короткой), сливаются в одну позицию со списком этапов `stages`
     и остальными формулировками в `merged`. Внесённые правки не сливаются.

Severity при эскалации: blocker зон facts/meaning, не попавший в текст, остаётся активным;
остальное уходит автору как author_choice (исходная severity — в поле orig_severity).

Использование:
    apply.py --text v1.md --findings findings.json --out v3.md [--report r.json]
             [--max-growth 0.2] [--protected protected.json]
    apply.py --length-check prev.md next.md [--max-loss 0.10] [--max-growth 0.2]
    apply.py --selftest

findings.json — список находок или {"findings": [...]}; находка:
    {stage, zone, severity: blocker|fix|author_choice, quote,
     action: applied|apply|suggest|redirect|flag, edit, source?}
    edit — дословный текст, которым заменить quote ("" = удалить; null = замены нет).
protected.json — {"protected_quotes": ["дословная строка", ...]} (якоря зерна, голос автора).

Вывод в stdout — краткая сводка (счётчики). Полный отчёт — в --report (JSON).
--length-check печатает и объём правки (edit_volume): долю изменённых слов (1 − ratio difflib
по словам, симметрично для вставок и удалений) и долю затронутых предложений исходника (diff по словам
и знакам препинания: поправленная запятая предложение затрагивает, но доли слов не меняет).
Это ориентир для отчёта, на код выхода не влияет; пороги по жанру подбираются на golden.

Exit: 0 — ок; 1 — ошибка входа; 2 — (--length-check) объём вне коридора.

Zero-dep, stdlib only.
"""

import argparse
import difflib
import json
import re
import sys

DEFAULT_MAX_GROWTH = 0.2
DEFAULT_MAX_LOSS = 0.10

APPLICABLE_SEVERITIES = {"fix", "blocker"}
ACTIONS = {"applied", "apply", "suggest", "redirect", "flag"}
# Синонимы apply, которые этапы возвращают вместо контрактного слова (прогон 03: Аграновский
# прислал «replace», и три проверенные правки фактов ушли автору). Только с непустым edit.
APPLY_ALIASES = {"replace", "fix", "edit", "correct"}
# Порог слияния позиций в разделе автора: доля перекрытия от более короткой цитаты.
AUTHOR_MERGE_OVERLAP = 0.6
# Зоны, где blocker без внесённой правки запрещает публикацию: ложный факт и смысловой дефект
# (внутреннее противоречие, логическая дыра). Стилистика и норма без правки — выбор автора.
HARD_ZONES = {"facts", "meaning"}


# ---------------------------------------------------------------- якорение

def _ws_pattern(quote):
    """Регэксп для quote с допуском: любой пробельный промежуток ↔ любой пробельный промежуток."""
    parts = [re.escape(p) for p in re.split(r"\s+", quote.strip()) if p]
    return re.compile(r"\s+".join(parts)) if parts else None


def locate(text, quote):
    """Вернуть список (start, end) всех вхождений quote. Сначала дословно, потом с допуском пробелов."""
    if not quote:
        return []
    spans = []
    i = text.find(quote)
    while i != -1:
        spans.append((i, i + len(quote)))
        i = text.find(quote, i + 1)
    if spans:
        return spans
    pat = _ws_pattern(quote)
    if pat is None:
        return []
    return [(m.start(), m.end()) for m in pat.finditer(text)]


# ---------------------------------------------------------------- ядро

def _norm_findings(raw):
    if isinstance(raw, dict):
        raw = raw.get("findings", [])
    if not isinstance(raw, list):
        raise ValueError("findings: ожидается список или {\"findings\": [...]}")
    out = []
    for n, f in enumerate(raw):
        if not isinstance(f, dict):
            raise ValueError(f"находка #{n}: не объект")
        g = dict(f)
        g["_id"] = n
        g["severity"] = str(g.get("severity") or "").strip()
        g["action"] = str(g.get("action") or "").strip()
        edit = g.get("edit")
        if g["action"].lower() in APPLY_ALIASES and isinstance(edit, str) and edit.strip():
            g["note"] = f"action нормализован: {g['action']} → apply"
            g["action"] = "apply"
        out.append(g)
    return out


def _to_author(item, reason):
    rec = {k: v for k, v in item.items() if not k.startswith("_")}
    rec["reason"] = reason
    return rec


def _hard(f):
    """Blocker, который вне текста остаётся активным: зоны фактов (выдуманный факт, 👤) и смысла
    (противоречие, которое этап-переписчик не смог снять сам). Стилистический blocker (кластер
    Слопотрона) без правки — это выбор автора, не запрет публикации."""
    return f["severity"] == "blocker" and str(f.get("zone") or "") in HARD_ZONES


def _span_overlap(a, b):
    return max(0, min(a[1], b[1]) - max(a[0], b[0]))


def _merge_author(text, to_author):
    """Слить позиции раздела автора, чьи цитаты вложены одна в другую или перекрываются в тексте
    ≥ AUTHOR_MERGE_OVERLAP от более короткой. Голова группы — самая длинная цитата; остальные
    формулировки сохраняются в `merged` (точный дубль цитаты и причины — только этапом в stages)."""
    quotes = [str(r.get("quote") or "").strip() for r in to_author]
    spans = []
    for q in quotes:
        found = locate(text, q)
        spans.append(found[0] if len(found) == 1 else None)

    def linked(i, j):
        qi, qj = quotes[i], quotes[j]
        if not qi or not qj:
            return False
        if qi in qj or qj in qi:
            return True
        si, sj = spans[i], spans[j]
        if si is None or sj is None:
            return False
        shorter = min(si[1] - si[0], sj[1] - sj[0])
        return shorter > 0 and _span_overlap(si, sj) / shorter >= AUTHOR_MERGE_OVERLAP

    parent = list(range(len(to_author)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(len(to_author)):
        for j in range(i + 1, len(to_author)):
            if linked(i, j):
                parent[root(j)] = root(i)
    groups = {}
    for i in range(len(to_author)):
        groups.setdefault(root(i), []).append(i)

    out = []
    for members in sorted(groups.values(), key=lambda m: m[0]):
        head_i = max(members, key=lambda i: (len(quotes[i]), -i))
        head = to_author[head_i]
        head["stages"] = sorted({str(to_author[i].get("stage", "?")) for i in members})
        merged = []
        for i in members:
            rec = to_author[i]
            if i == head_i or (quotes[i] == quotes[head_i] and rec["reason"] == head["reason"]):
                continue
            merged.append({k: rec.get(k) for k in ("stage", "quote", "edit", "severity", "reason")})
        if merged:
            head["merged"] = merged
        out.append(head)
    return out


def apply_findings(text, findings, max_growth=DEFAULT_MAX_GROWTH, protected=None):
    """Single-apply. Возвращает (new_text, report).

    protected — список дословных строк, которые правки не трогают (см. --protected)."""
    findings = _norm_findings(findings)
    applied, to_author, active_blockers, passthrough = [], [], [], []

    def escalate(f, reason):
        rec = _to_author(f, reason)
        if _hard(f):
            active_blockers.append(rec)
        else:
            if rec["severity"] != "author_choice":
                rec["orig_severity"] = rec["severity"]
                rec["severity"] = "author_choice"
            to_author.append(rec)

    # 1. раскладка
    candidates = []
    for f in findings:
        sev, act, edit = f["severity"], f["action"], f.get("edit")
        if act not in ACTIONS:
            escalate(f, f"неизвестный action «{act}» — не вносится")
            continue
        if act == "applied":
            passthrough.append(_to_author(f, "уже внесено этапом-переписчиком"))
            continue
        if act == "flag":
            escalate(f, "замены нет — нужен автор или эксперт")
            continue
        if sev == "author_choice" or act == "suggest":
            to_author.append(_to_author(f, "author_choice"))
            continue
        if sev not in APPLICABLE_SEVERITIES:
            escalate(f, f"неизвестная severity «{sev}»")
            continue
        if edit is None:
            escalate(f, "edit: null — замены нет (ручная правка / эксперт)" if _hard(f)
                     else "этап не дал замены")
            continue
        if not isinstance(edit, str):
            escalate(f, "edit не строка")
            continue
        if not str(f.get("quote") or "").strip():
            escalate(f, "нет quote — нечего якорить")
            continue
        candidates.append(f)

    # 2. дедуп по quote
    by_quote = {}
    for f in candidates:
        by_quote.setdefault(f["quote"].strip(), []).append(f)
    unique = []
    for q, group in by_quote.items():
        edits = {g["edit"] for g in group}
        if len(edits) > 1:
            for g in group:
                escalate(g, "конфликт: одна цитата, разные замены у этапов")
            continue
        head = dict(group[0])
        head["_stages"] = sorted({str(g.get("stage", "?")) for g in group})
        head["_severity"] = "blocker" if any(g["severity"] == "blocker" for g in group) \
            else head["severity"]
        head["severity"] = head["_severity"]
        unique.append(head)

    # 3. якорение
    anchored = []
    for f in unique:
        spans = locate(text, f["quote"])
        if not spans:
            escalate(f, "цитата не найдена в тексте дословно")
        elif len(spans) > 1:
            escalate(f, f"цитата неоднозначна: {len(spans)} вхождения")
        else:
            f["_span"] = spans[0]
            f["_growth"] = len(f["edit"]) - (spans[0][1] - spans[0][0])
            anchored.append(f)

    # 3а. защищённые цитаты: правка, задевающая защищённую строку, не вносится
    protected = [str(q).strip() for q in (protected or []) if str(q or "").strip()]
    protected_spans, protected_missing = [], []
    for q in protected:
        found = locate(text, q)
        protected_spans.extend(found)
        if not found:
            protected_missing.append(q)
    if protected_spans:
        kept = []
        for f in anchored:
            s, e = f["_span"]
            if any(_span_overlap((s, e), ps) > 0 for ps in protected_spans):
                escalate(f, "защищённая цитата — правка её задевает")
            else:
                kept.append(f)
        anchored = kept

    # 4а. вложенная правка: точечная находка внутри абзаца-замены (кластер Слопотрона ⊃ факт
    # Аграновского). Если её quote ровно один раз есть в edit внешней правки — применить внутри.
    nested_applied = []
    for outer in sorted(anchored, key=lambda f: f["_span"][0] - f["_span"][1]):
        if outer.get("_nested_into"):
            continue
        for inner in anchored:
            if inner is outer or inner.get("_nested_into"):
                continue
            (os_, oe), (is_, ie) = outer["_span"], inner["_span"]
            if os_ <= is_ and ie <= oe and (os_, oe) != (is_, ie) \
                    and outer["edit"].count(inner["quote"].strip()) == 1:
                outer["edit"] = outer["edit"].replace(inner["quote"].strip(), inner["edit"])
                outer["_growth"] = len(outer["edit"]) - (oe - os_)
                outer["_stages"] = sorted(set(outer["_stages"]) | set(inner["_stages"]))
                if inner["severity"] == "blocker":
                    outer["_carries_hard"] = outer.get("_carries_hard") or _hard(inner)
                inner["_nested_into"] = outer
                nested_applied.append(inner)
    anchored = [f for f in anchored if not f.get("_nested_into")]

    # 4б. перекрытие span (геометрия по исходному тексту)
    anchored.sort(key=lambda f: f["_span"])
    overlapping = set()
    for a in range(len(anchored)):
        for b in range(a + 1, len(anchored)):
            if anchored[b]["_span"][0] >= anchored[a]["_span"][1]:
                break
            overlapping.add(a)
            overlapping.add(b)
    ok = []
    for i, f in enumerate(anchored):
        if i in overlapping:
            escalate(f, "перекрытие span с другой правкой")
        else:
            ok.append(f)

    # 5. бюджет роста: исправление факта проходит всегда, остальное — от меньшего прироста к большему
    immune = lambda f: _hard(f) or f.get("_carries_hard")
    budget = int(max_growth * len(text))
    growth = sum(max(0, f["_growth"]) for f in ok if immune(f))
    accepted = [f for f in ok if immune(f)]
    for f in sorted((f for f in ok if not immune(f)), key=lambda f: f["_growth"]):
        g = max(0, f["_growth"])
        if g > 0 and growth + g > budget:
            escalate(f, f"бюджет роста: +{g} знаков сверх лимита {budget} "
                        f"({max_growth:.0%} от {len(text)})")
            continue
        growth += g
        accepted.append(f)

    # 6. применение с конца
    new_text = text
    for f in sorted(accepted, key=lambda f: f["_span"][0], reverse=True):
        s, e = f["_span"]
        new_text = new_text[:s] + f["edit"] + new_text[e:]
        rec = _to_author(f, "applied")
        rec["stages"] = f["_stages"]
        rec["span"] = [s, e]
        rec["growth"] = f["_growth"]
        if f["severity"] == "blocker":
            rec["reason"] = "blocker снят правкой"
        applied.append(rec)
    accepted_ids = {id(f) for f in accepted}
    for inner in nested_applied:
        outer = inner["_nested_into"]
        if id(outer) in accepted_ids:
            rec = _to_author(inner, f"применено внутри правки абзаца ({', '.join(outer['_stages'])})")
            rec["stages"], rec["span"], rec["growth"] = inner["_stages"], list(inner["_span"]), None
            applied.append(rec)
        else:
            escalate(inner, "внешняя правка абзаца не применена: " + "бюджет роста/перекрытие")
    applied.sort(key=lambda r: r["span"][0])

    # одна фраза от нескольких этапов в разделе автора — одна позиция с атрибуцией всех
    to_author = _merge_author(text, to_author)

    report = {
        "len_before": len(text),
        "len_after": len(new_text),
        "growth_budget": budget,
        "growth_used": growth,
        "applied": applied,
        "to_author": to_author,
        "active_blockers": active_blockers,
        "already_applied": passthrough,
    }
    if protected:
        report["protected_quotes"] = len(protected)
        report["protected_not_found"] = protected_missing
    return new_text, report


def length_check(prev, nxt, max_loss=DEFAULT_MAX_LOSS, max_growth=DEFAULT_MAX_GROWTH):
    """Коридор объёма для этапов-переписчиков: (status, ratio). status ∈ ok|loss|growth."""
    a, b = len(prev.strip()), len(nxt.strip())
    if a == 0:
        return ("ok" if b == 0 else "growth"), None
    ratio = (b - a) / a
    if ratio < -max_loss:
        return "loss", ratio
    if ratio > max_growth:
        return "growth", ratio
    return "ok", ratio


_TOKEN_RE = re.compile(r"\w+(?:[-'’]\w+)*|[^\w\s]")
_SENT_RE = re.compile(r"[^\n]+?(?:[.!?…]+[»\"’)]*(?=\s|$)|$)", re.M)


def _sentence_spans(text):
    return [(m.start(), m.end()) for m in _SENT_RE.finditer(text) if m.group().strip()]


def edit_volume(prev, nxt):
    """Объём правки prev→nxt: доля изменённых слов и доля затронутых предложений prev.

    Слова: 1 − ratio SequenceMatcher по словам (без знаков препинания). Предложения: diff по словам
    и знакам препинания; предложение prev затронуто, если в него попала замена/удаление или вставка.
    """
    words_a = [m.group() for m in _TOKEN_RE.finditer(prev) if m.group()[0].isalnum() or m.group()[0] == "_"]
    words_b = [m.group() for m in _TOKEN_RE.finditer(nxt) if m.group()[0].isalnum() or m.group()[0] == "_"]
    sm = difflib.SequenceMatcher(None, words_a, words_b, autojunk=False)
    word_share = 1 - sm.ratio() if (words_a or words_b) else 0.0

    toks_a = list(_TOKEN_RE.finditer(prev))
    toks_b = [m.group() for m in _TOKEN_RE.finditer(nxt)]
    spans = _sentence_spans(prev)
    sent_of = []  # индекс предложения для каждого токена prev
    k = 0
    for t in toks_a:
        while k < len(spans) - 1 and t.start() >= spans[k][1]:
            k += 1
        sent_of.append(k)
    touched = set()
    sm2 = difflib.SequenceMatcher(None, [t.group() for t in toks_a], toks_b, autojunk=False)
    for op, i1, i2, _j1, _j2 in sm2.get_opcodes():
        if op == "equal" or not sent_of:
            continue
        if i1 < i2:
            touched.update(sent_of[i1:i2])
        else:  # чистая вставка — к предложению соседнего токена prev
            touched.add(sent_of[min(i1, len(sent_of)) - 1] if i1 > 0 else sent_of[0])
    total = len(spans)
    return {
        "word_share": round(word_share, 4),
        "words_before": len(words_a),
        "words_after": len(words_b),
        "sentences_touched": len(touched),
        "sentences_total": total,
        "sentence_share": round(len(touched) / total, 4) if total else 0.0,
    }


def format_edit_volume(v):
    return (f"edit-volume: слова {v['word_share']:.1%} ({v['words_before']}→{v['words_after']}); "
            f"предложения {v['sentences_touched']}/{v['sentences_total']} ({v['sentence_share']:.0%})")


# ---------------------------------------------------------------- selftest

def selftest():
    fails, seen = [], []

    def check(name, cond):
        seen.append(name)
        if not cond:
            fails.append(name)

    F = lambda **kw: dict({"stage": "slopotron", "zone": "ai-markers", "action": "apply"}, **kw)

    # 1. простая правка + author_choice не вносится
    t = "В современном мире важно отметить, что рынок растёт."
    out, r = apply_findings(t, [
        F(severity="fix", quote="В современном мире важно отметить, что рынок",
          edit="Рынок"),
        F(severity="author_choice", action="suggest", quote="растёт", edit="рос"),
    ])
    check("simple-apply", out == "Рынок растёт.")
    check("author-choice-untouched", len(r["to_author"]) == 1 and "растёт" in out)

    # 2. удаление edit=""
    out, _ = apply_findings("Раз. Лишнее. Два.", [F(severity="fix", quote=" Лишнее.", edit="")])
    check("delete", out == "Раз. Два.")

    # 3. перекрытие: обе автору, blocker остаётся активным
    t = "Компания выросла на 40% за год благодаря синергии."
    out, r = apply_findings(t, [
        F(stage="agranovsky", zone="facts", severity="blocker",
          quote="выросла на 40% за год", edit="выросла на 12% за год"),
        F(severity="fix", quote="за год благодаря синергии", edit="за год"),
    ])
    check("overlap-untouched", out == t)
    check("overlap-blocker-active", len(r["active_blockers"]) == 1 and len(r["to_author"]) == 1)

    # 4. цитата не найдена / неоднозначна
    t = "Это важно. Это важно."
    out, r = apply_findings(t, [
        F(severity="fix", quote="Это важно.", edit="Важно."),
        F(severity="fix", quote="нет такой", edit="x"),
    ])
    check("ambiguous-and-missing", out == t and len(r["to_author"]) == 2)

    # 5. допуск пробелов (NBSP / перенос строки внутри цитаты)
    t = "Рынок диктует\nправила игры."
    out, _ = apply_findings(t, [F(severity="fix", quote="Рынок диктует правила", edit="Правила задаёт спрос:")])
    check("whitespace-tolerant", out == "Правила задаёт спрос: игры.")

    # 6. бюджет роста: вытесняется самая раздувающая, blocker — никогда
    t = "а" * 100 + " X " + "б" * 100 + " Y " + "в" * 100 + " Z " + "г" * 100
    budget_text_len = len(t)                      # 412 → бюджет 0.2 = 82
    out, r = apply_findings(t, [
        F(severity="fix", quote=" X ", edit=" " + "x" * 40 + " "),     # +40
        F(severity="fix", quote=" Y ", edit=" " + "y" * 60 + " "),     # +60 — вытесняется
        F(stage="agranovsky", zone="facts", severity="blocker",
          quote=" Z ", edit=" " + "z" * 30 + " "),                            # +30, blocker
    ], max_growth=0.2)
    check("budget-evicts-largest", "y" * 60 not in out and "x" * 40 in out)
    check("budget-keeps-blocker", "z" * 30 in out)
    check("budget-report", any("бюджет роста" in a["reason"] for a in r["to_author"])
          and r["growth_used"] <= int(0.2 * budget_text_len))

    # 7. дедуп: одна цитата и одна замена от двух этапов → одна правка, blocker побеждает
    t = "Эксперты считают, что рынок вырос."
    out, r = apply_findings(t, [
        F(severity="author_choice", action="suggest", quote="рынок", edit=None),
        F(severity="fix", quote="Эксперты считают, что рынок", edit="Рынок"),
        F(stage="agranovsky", zone="facts", severity="blocker",
          quote="Эксперты считают, что рынок", edit="Рынок"),
    ])
    check("dedup", out == "Рынок вырос." and len(r["applied"]) == 1
          and r["applied"][0]["stages"] == ["agranovsky", "slopotron"]
          and r["applied"][0]["reason"] == "blocker снят правкой")

    # 8. конфликт замен
    out, r = apply_findings("Цифра 40%.", [
        F(severity="fix", quote="40%", edit="12%"),
        F(stage="agranovsky", zone="facts", severity="blocker", quote="40%", edit="15%"),
    ])
    check("conflict", out == "Цифра 40%." and len(r["active_blockers"]) == 1 and len(r["to_author"]) == 1)

    # 9. edit null: blocker активен, fix → автору
    out, r = apply_findings("Закон № 999-ФЗ.", [
        F(stage="agranovsky", zone="facts", severity="blocker", quote="№ 999-ФЗ", edit=None),
        F(stage="agranovsky", zone="facts", severity="fix", quote="Закон", edit=None),
    ])
    check("edit-null", out == "Закон № 999-ФЗ." and len(r["active_blockers"]) == 1
          and r["to_author"][0]["reason"] == "этап не дал замены")

    # 10. несколько правок — позиции не съезжают
    t = "один два три четыре пять"
    out, _ = apply_findings(t, [
        F(severity="fix", quote="два", edit="ДВА-ДВА"),
        F(severity="fix", quote="четыре", edit="4"),
        F(severity="fix", quote="один", edit=""),
    ], max_growth=1.0)
    check("multi-positions", out == " ДВА-ДВА три 4 пять")

    # 11. applied от переписчика не трогаем
    out, r = apply_findings("текст", [dict(stage="chukovsky", severity="fix",
                                           action="applied", quote="текст", edit="ТЕКСТ")])
    check("passthrough", out == "текст" and len(r["already_applied"]) == 1)

    # 12. дубль в разделе автора склеивается
    _, r = apply_findings("Эксперты считают так.", [
        F(severity="author_choice", action="suggest", quote="Эксперты считают", edit=None),
        F(stage="agranovsky", severity="author_choice", action="suggest", quote="Эксперты считают", edit=None),
    ])
    check("author-dedup", len(r["to_author"]) == 1 and r["to_author"][0]["stages"] == ["agranovsky", "slopotron"])

    # 13. кластер Слопотрона без edit — автору, не активный blocker; severity в разделе автора = author_choice
    _, r = apply_findings("Абзац со слопом.", [F(severity="blocker", action="redirect",
                                                  quote="Абзац со слопом.", edit=None)])
    check("style-blocker-not-hard", not r["active_blockers"] and r["to_author"][0]["severity"] == "author_choice"
          and r["to_author"][0]["orig_severity"] == "blocker")

    # 14. стилистический blocker вытесняется бюджетом, факт — нет
    t = "а" * 100 + " P " + "б" * 100
    out, r = apply_findings(t, [
        F(severity="blocker", action="redirect", quote=" P ", edit=" " + "p" * 80 + " "),
    ], max_growth=0.2)
    check("style-blocker-budget", "p" * 80 not in out and not r["active_blockers"])

    # 15. факт внутри абзаца-замены применяется вложенно
    t = "Рынок вырос на 40% за год, это синергия и экосистема. Второй абзац."
    out, r = apply_findings(t, [
        F(severity="blocker", action="redirect",
          quote="Рынок вырос на 40% за год, это синергия и экосистема.", edit="Рынок вырос на 40% за год."),
        F(stage="agranovsky", zone="facts", severity="blocker", quote="40%", edit="12%"),
    ])
    check("nested-apply", out == "Рынок вырос на 12% за год. Второй абзац." and len(r["applied"]) == 2
          and not r["active_blockers"])
    # ...а если абзац-замена выкинул факт — конфликт, факт остаётся активным
    out, r = apply_findings(t, [
        F(severity="blocker", action="redirect",
          quote="Рынок вырос на 40% за год, это синергия и экосистема.", edit="Рынок вырос."),
        F(stage="agranovsky", zone="facts", severity="blocker", quote="40%", edit="12%"),
    ])
    check("nested-conflict", out == t and len(r["active_blockers"]) == 1)

    # 16а. контракт action: неизвестный не вносится; flag смысла — активный blocker
    t = "Продажи выросли на 40%. Выручка упала вдвое."
    out, r = apply_findings(t, [F(severity="fix", action="verify", quote="на 40%", edit="на 4%")])
    check("unknown-action-not-applied", out == t and len(r["to_author"]) == 1
          and "неизвестный action" in r["to_author"][0]["reason"])
    out, r = apply_findings(t, [F(stage="chukovsky", zone="meaning", severity="blocker",
                                  action="flag", quote="Выручка упала вдвое.", edit=None)])
    check("meaning-flag-active", out == t and len(r["active_blockers"]) == 1)
    out, r = apply_findings(t, [F(stage="chukovsky", zone="meaning", severity="author_choice",
                                  action="flag", quote="Выручка упала вдвое.", edit=None)])
    check("meaning-flag-choice-not-active", out == t and not r["active_blockers"])
    out, r = apply_findings(t, [F(zone="ai-markers", severity="blocker", action="flag",
                                  quote="Выручка упала вдвое.", edit=None)])
    check("style-flag-not-active", not r["active_blockers"] and len(r["to_author"]) == 1)

    # 16б. E5: синонимы apply с непустым edit приводятся к apply, с пометкой
    t = "Главное подметил другой коллега. Клиент цепляется за частности."
    out, r = apply_findings(t, [
        F(stage="agranovsky", zone="facts", severity="fix", action="replace",
          quote="другой коллега", edit="другой участник команды"),
        F(stage="agranovsky", zone="facts", severity="fix", action="Correct",
          quote="Клиент цепляется", edit="Одна из представителей клиента цепляется"),
    ], max_growth=1.0)
    check("alias-apply", out == "Главное подметил другой участник команды. "
          "Одна из представителей клиента цепляется за частности." and len(r["applied"]) == 2
          and r["applied"][0]["note"] == "action нормализован: replace → apply"
          and r["applied"][1]["note"] == "action нормализован: Correct → apply")
    out, r = apply_findings(t, [
        F(severity="fix", action="replace", quote="другой коллега", edit=""),
        F(severity="fix", action="rewrite", quote="Клиент", edit="Заказчик"),
    ])
    check("alias-needs-edit", out == t and len(r["to_author"]) == 2
          and all("неизвестный action" in a["reason"] for a in r["to_author"]))

    # 16в. E6: позиции автора с вложенными / перекрытыми цитатами сливаются, правки — нет
    t = "Всё решила одна фраза. Клиент услышал своё слово и согласился. Конец."
    out, r = apply_findings(t, [
        F(stage="chukovsky", severity="author_choice", action="suggest",
          quote="Всё решила одна фраза.", edit=None),
        F(stage="agranovsky", zone="facts", severity="fix", action="flag",
          quote="Всё решила одна фраза", edit=None),
        F(severity="author_choice", action="suggest", quote="решила одна фраза. Клиент", edit=None),
        F(severity="author_choice", action="suggest", quote="Конец.", edit=None),
    ])
    pos = [a for a in r["to_author"] if "фраза" in a["quote"]]
    check("author-merge-overlap", len(r["to_author"]) == 2 and len(pos) == 1
          and pos[0]["stages"] == ["agranovsky", "chukovsky", "slopotron"]
          and len(pos[0]["merged"]) == 2)
    _, r = apply_findings("Раз два три четыре пять шесть семь.", [
        F(severity="author_choice", action="suggest", quote="Раз два три четыре", edit=None),
        F(stage="chukovsky", severity="author_choice", action="suggest", quote="четыре пять шесть семь.",
          edit=None),
    ])
    check("author-merge-low-overlap", len(r["to_author"]) == 2)
    out, r = apply_findings("Рынок вырос на 40% за год.", [
        F(severity="fix", quote="Рынок вырос", edit="Рынок прибавил"),
        F(stage="agranovsky", severity="author_choice", action="suggest", quote="Рынок вырос на 40%",
          edit=None),
    ])
    check("author-merge-skips-applied", out == "Рынок прибавил на 40% за год."
          and len(r["applied"]) == 1 and len(r["to_author"]) == 1)

    # 16г. защищённые цитаты: правка, задевающая якорь, не вносится; соседняя — вносится
    t = "Это я к чему. Ага? Решение принимают по слову. В современном мире всё сложно."
    out, r = apply_findings(t, [
        F(severity="fix", quote="Это я к чему. Ага?", edit=""),
        F(severity="fix", quote="В современном мире всё", edit="Всё"),
        F(severity="blocker", action="redirect", quote="Решение принимают по слову.",
          edit="Решения принимают по словам."),
    ], protected=["Ага?", "принимают по слову"])
    check("protected-blocks", out == "Это я к чему. Ага? Решение принимают по слову. Всё сложно."
          and len(r["applied"]) == 1 and len(r["to_author"]) == 2
          and all("защищённая цитата" in a["reason"] for a in r["to_author"]))
    out, r = apply_findings("Цифра 40% тут.", [
        F(stage="agranovsky", zone="facts", severity="blocker", quote="40%", edit="12%"),
    ], protected=["Цифра 40%", "нет в тексте"])
    check("protected-fact-active", out == "Цифра 40% тут." and len(r["active_blockers"]) == 1
          and r["protected_not_found"] == ["нет в тексте"])

    # 16. коридор объёма
    check("len-ok", length_check("a" * 100, "a" * 95)[0] == "ok")
    check("len-loss", length_check("a" * 100, "a" * 85)[0] == "loss")
    check("len-growth", length_check("a" * 100, "a" * 125)[0] == "growth")

    # 17. объём правки
    src = "Мы провели анализ рынка. Выручка выросла вдвое! Это хорошо."
    v = edit_volume(src, src)
    check("vol-zero", v["word_share"] == 0 and v["sentences_touched"] == 0 and v["sentences_total"] == 3)
    v = edit_volume(src, "Мы изучили рынок. Выручка выросла вдвое! Это хорошо.")
    check("vol-one-sentence", v["sentences_touched"] == 1 and 0.1 < v["word_share"] < 0.4)
    v = edit_volume("Он сказал что придёт. Всё.", "Он сказал, что придёт. Всё.")
    check("vol-comma-only", v["word_share"] == 0 and v["sentences_touched"] == 1)
    v = edit_volume(src, "Совсем другой текст про погоду в Москве.")
    check("vol-rewrite", v["word_share"] > 0.9 and v["sentence_share"] == 1)
    v = edit_volume("Раз. Два.", "Раз. Два. Три.")
    check("vol-append", v["sentences_touched"] == 1 and v["word_share"] > 0)

    total = len(seen)
    if fails:
        print(f"selftest: FAIL {total - len(fails)}/{total} — " + ", ".join(fails))
        return 1
    print(f"selftest: PASS {total}/{total}")
    return 0


# ---------------------------------------------------------------- CLI

def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def main(argv=None):
    p = argparse.ArgumentParser(description="Детерминированный single-apply Редколлегии")
    p.add_argument("--text", help="text_v1 (после Чуковского)")
    p.add_argument("--findings", help="JSON находок Detect-этапов")
    p.add_argument("--out", help="куда записать text_v3")
    p.add_argument("--report", help="куда записать полный JSON-отчёт")
    p.add_argument("--max-growth", type=float, default=DEFAULT_MAX_GROWTH)
    p.add_argument("--protected", help='JSON {"protected_quotes": [...]} — строки, которые правки не трогают')
    p.add_argument("--max-loss", type=float, default=DEFAULT_MAX_LOSS)
    p.add_argument("--length-check", nargs=2, metavar=("PREV", "NEXT"))
    p.add_argument("--selftest", action="store_true")
    a = p.parse_args(argv)

    if a.selftest:
        return selftest()

    if a.length_check:
        status, ratio = length_check(_read(a.length_check[0]), _read(a.length_check[1]),
                                     a.max_loss, a.max_growth)
        shown = "n/a" if ratio is None else f"{ratio:+.1%}"
        print(f"length-check: {status} ({shown}; коридор −{a.max_loss:.0%}…+{a.max_growth:.0%})")
        print(format_edit_volume(edit_volume(_read(a.length_check[0]), _read(a.length_check[1]))))
        return 0 if status == "ok" else 2

    if not (a.text and a.findings and a.out):
        p.error("нужны --text, --findings и --out (или --selftest / --length-check)")
    try:
        text = _read(a.text)
        findings = json.loads(_read(a.findings))
        protected = None
        if a.protected:
            prot = json.loads(_read(a.protected))
            protected = prot.get("protected_quotes") if isinstance(prot, dict) else None
            if not isinstance(protected, list):
                raise ValueError("protected: ожидается {\"protected_quotes\": [...]}")
        new_text, report = apply_findings(text, findings, a.max_growth, protected)
    except (OSError, ValueError) as e:
        print(f"ошибка: {e}", file=sys.stderr)
        return 1

    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write(new_text)
    if a.report:
        with open(a.report, "w", encoding="utf-8") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2)

    print(f"applied: {len(report['applied'])} | to_author: {len(report['to_author'])} | "
          f"active_blockers: {len(report['active_blockers'])} | "
          f"growth: +{report['growth_used']}/{report['growth_budget']} | "
          f"len {report['len_before']}→{report['len_after']}")
    notes = sum(1 for k in ("applied", "to_author", "active_blockers")
                for r in report[k] if r.get("note"))
    if notes:
        print(f"action нормализован: {notes}")
    if report.get("protected_not_found"):
        print(f"защищённые цитаты не найдены в тексте: {len(report['protected_not_found'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
