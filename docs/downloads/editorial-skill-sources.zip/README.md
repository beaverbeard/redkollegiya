# Источники / Source kit

Восемь публичных скиллов, без изменения инструкций и без личных корпусов. Это исходники для подключения и адаптации, не проверенный универсальный установщик. Распакуйте этот архив; в Claude/Gemini загружаются восемь отдельных ZIP внутри, не внешний архив.

Eight unchanged public skill payloads, without personal corpora. These are sources for setup and adaptation, not a validated universal installer. Extract this archive; Claude/Gemini accept the eight individual skill ZIPs inside, not this outer archive.
